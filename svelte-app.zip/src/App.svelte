<script>
	let cnnSite = "";
	
	var request = new Request('https://www.cnn.com');
	fetch(request).then(function(response) {
  	return response.text();
		}).then(function(text) {
  		cnnSite = text;
		});


	function getArticle(){

	};
 
	
	
	
	
</script>


<p>
 {cnnSite}
</p>